"use client"

import { Card } from "@/components/ui/card"
import type { Vehicle } from "@/lib/types"

interface StatisticsProps {
  vehicles: Vehicle[]
  currentMonth: string
}

export function Statistics({ vehicles, currentMonth }: StatisticsProps) {
  const getStats = () => {
    let increases = 0
    let decreases = 0
    let totalIncrease = 0
    let totalDecrease = 0
    let comparableVehicles = 0

    vehicles.forEach((vehicle) => {
      const months = Object.keys(vehicle.prices).sort()
      const currentIndex = months.indexOf(currentMonth)

      if (currentIndex > 0) {
        comparableVehicles++
        const currentPrice = vehicle.prices[currentMonth]
        const previousPrice = vehicle.prices[months[currentIndex - 1]]
        const diff = currentPrice - previousPrice

        if (diff > 0) {
          increases++
          totalIncrease += diff
        } else if (diff < 0) {
          decreases++
          totalDecrease += Math.abs(diff)
        }
      }
    })

    const avgIncrease = increases > 0 ? totalIncrease / increases : 0
    const avgDecrease = decreases > 0 ? totalDecrease / decreases : 0

    return {
      total: vehicles.length,
      comparable: comparableVehicles,
      increases,
      decreases,
      stable: comparableVehicles - increases - decreases,
      totalIncrease,
      totalDecrease,
      avgIncrease,
      avgDecrease,
    }
  }

  const stats = getStats()

  const statCards = [
    { label: "Total de vehículos", value: stats.total, color: "text-blue-600" },
    { label: "Con comparativa", value: stats.comparable, color: "text-blue-600" },
    { label: "Aumentaron de precio", value: stats.increases, color: "text-red-600" },
    { label: "Bajaron de precio", value: stats.decreases, color: "text-green-600" },
    { label: "Precio estable", value: stats.stable, color: "text-slate-600" },
  ]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        {statCards.map((stat, idx) => (
          <Card key={idx} className="p-6 text-center">
            <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
            <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
          </Card>
        ))}
      </div>

      {stats.comparable > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Resumen de cambios</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-muted-foreground text-sm mb-2">Total aumentado</p>
              <p className="text-2xl font-bold text-red-600">${stats.totalIncrease.toLocaleString("es-AR")}</p>
              <p className="text-xs text-muted-foreground mt-1">Promedio: ${stats.avgIncrease.toFixed(0)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-sm mb-2">Total disminuido</p>
              <p className="text-2xl font-bold text-green-600">-${stats.totalDecrease.toLocaleString("es-AR")}</p>
              <p className="text-xs text-muted-foreground mt-1">Promedio: ${stats.avgDecrease.toFixed(0)}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-sm mb-2">Neto</p>
              <p
                className={`text-2xl font-bold ${stats.totalIncrease - stats.totalDecrease >= 0 ? "text-red-600" : "text-green-600"}`}
              >
                {stats.totalIncrease - stats.totalDecrease >= 0 ? "+" : "-"}$
                {Math.abs(stats.totalIncrease - stats.totalDecrease).toLocaleString("es-AR")}
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}
