"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { addVehicle, updateVehiclePrice } from "@/lib/vehicle-service"

interface ImportedVehicle {
  name: string
  description?: string
  price: number
}

interface CSVImporterProps {
  onImport: () => void
  currentMonth: string
}

export function CSVImporter({ onImport, currentMonth }: CSVImporterProps) {
  const [preview, setPreview] = useState<ImportedVehicle[]>([])
  const [isProcessing, setIsProcessing] = useState(false)
  const [isImporting, setIsImporting] = useState(false)

  const parseCSV = (csv: string) => {
    const lines = csv.split("\n").filter((line) => line.trim())
    const headers = lines[0].split(",").map((h) => h.trim().toLowerCase())

    const vehicles: ImportedVehicle[] = []

    for (let i = 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue

      const values = lines[i].split(",").map((v) => v.trim())
      const vehicle: ImportedVehicle = {
        name: values[headers.indexOf("nombre")] || values[0] || "",
        description: values[headers.indexOf("descripción")] || values[headers.indexOf("description")] || "",
        price: Number.parseFloat(
          values[headers.indexOf("precio_actual")] || values[headers.indexOf("precio actual")] || "0",
        ),
      }

      if (vehicle.name && vehicle.price) {
        vehicles.push(vehicle)
      }
    }

    return vehicles
  }

  const parseExcel = async (file: File) => {
    return new Promise<ImportedVehicle[]>((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = async (event) => {
        try {
          const { read, utils } = await import("xlsx")
          const data = event.target?.result as ArrayBuffer
          const workbook = read(data, { type: "array" })
          const firstSheet = workbook.Sheets[workbook.SheetNames[0]]
          const rows = utils.sheet_to_json(firstSheet)

          const vehicles: ImportedVehicle[] = rows
            .map((row: any) => ({
              name: row.nombre || row.Nombre || row.name || row.Name || "",
              description: row.descripción || row.Descripción || row.description || row.Description || "",
              price: Number.parseFloat(row.precio_actual || row["Precio Actual"] || row.precio || row.Precio || "0"),
            }))
            .filter((v) => v.name && v.price)

          resolve(vehicles)
        } catch (error) {
          reject(error)
        }
      }

      reader.onerror = () => reject(new Error("Error reading file"))
      reader.readAsArrayBuffer(file)
    })
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsProcessing(true)

    try {
      let vehicles: ImportedVehicle[] = []

      if (file.name.endsWith(".csv")) {
        const text = await file.text()
        vehicles = parseCSV(text)
      } else if (file.name.endsWith(".xlsx") || file.name.endsWith(".xls") || file.type.includes("spreadsheet")) {
        vehicles = await parseExcel(file)
      } else {
        alert("Formato no soportado. Por favor usa CSV o Excel (.xlsx, .xls)")
        setIsProcessing(false)
        return
      }

      setPreview(vehicles)
    } catch (error) {
      alert("Error al procesar el archivo")
      console.error(error)
    } finally {
      setIsProcessing(false)
    }
  }

  const handleImport = async () => {
    if (preview.length === 0) {
      alert("No hay vehículos para importar")
      return
    }

    try {
      setIsImporting(true)
      for (const vehicle of preview) {
        const newVehicle = await addVehicle(vehicle.name, vehicle.description || "")
        await updateVehiclePrice(newVehicle.id, currentMonth, vehicle.price)
      }
      setPreview([])
      alert(`${preview.length} vehículos importados exitosamente para ${currentMonth}`)
      onImport()
    } catch (error) {
      console.error("Error importing vehicles:", error)
      alert("Error al importar los vehículos")
    } finally {
      setIsImporting(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Importar desde Excel o CSV</h3>
        <p className="text-sm text-muted-foreground mb-4">Soporta archivos: CSV, Excel (.xlsx, .xls)</p>
        <p className="text-xs text-muted-foreground mb-4">
          Columnas requeridas: nombre, precio_actual. Opcional: descripción
        </p>
        <input
          type="file"
          accept=".csv,.xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
          onChange={handleFileChange}
          disabled={isProcessing || isImporting}
          className="block w-full text-sm text-slate-500
            file:mr-4 file:py-2 file:px-4
            file:rounded-md file:border-0
            file:text-sm file:font-semibold
            file:bg-slate-200 file:text-slate-700
            hover:file:bg-slate-300
            disabled:opacity-50
          "
        />
        {isProcessing && <p className="text-xs text-muted-foreground mt-2">Procesando archivo...</p>}
      </Card>

      {preview.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Vista previa ({preview.length} vehículos)</h3>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {preview.map((vehicle, idx) => (
              <div key={idx} className="border border-border rounded p-3 text-sm">
                <p className="font-semibold">{vehicle.name}</p>
                {vehicle.description && <p className="text-muted-foreground text-xs">{vehicle.description}</p>}
                <p className="text-xs text-muted-foreground mt-1">${vehicle.price.toLocaleString("es-AR")}</p>
              </div>
            ))}
          </div>
          <Button onClick={handleImport} className="w-full mt-4" disabled={isImporting}>
            {isImporting ? "Importando..." : `Importar ${preview.length} vehículos`}
          </Button>
        </Card>
      )}

      <Card className="p-6 bg-slate-50 dark:bg-slate-900">
        <h3 className="text-sm font-semibold text-foreground mb-3">Formatos soportados</h3>
        <div className="space-y-3 text-xs text-muted-foreground">
          <div>
            <p className="font-semibold text-foreground mb-1">CSV:</p>
            <pre className="overflow-x-auto">
              {`nombre,descripción,precio_actual
Toyota Corolla 2020,Azul 80km,1200000
Honda Civic 2019,Gris 95km,1050000`}
            </pre>
          </div>
          <div>
            <p className="font-semibold text-foreground mb-1">Excel: Mismas columnas en tu archivo .xlsx</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
