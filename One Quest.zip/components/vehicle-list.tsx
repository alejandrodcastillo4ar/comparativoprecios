"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import type { Vehicle } from "@/lib/types"

interface VehicleListProps {
  vehicles: Vehicle[]
  currentMonth: string
  onUpdatePrice: (vehicleId: string, newPrice: number) => void
  onDelete: (vehicleId: string) => void
}

export function VehicleList({ vehicles, currentMonth, onUpdatePrice, onDelete }: VehicleListProps) {
  const getPriceChange = (vehicle: Vehicle) => {
    const currentPrice = vehicle.prices[currentMonth]
    const months = Object.keys(vehicle.prices).sort()
    const currentIndex = months.indexOf(currentMonth)

    if (currentIndex <= 0 || !currentPrice) return null

    const previousMonth = months[currentIndex - 1]
    const previousPrice = vehicle.prices[previousMonth]

    const diff = currentPrice - previousPrice
    const percent = ((diff / previousPrice) * 100).toFixed(2)

    return { diff, percent, previous: previousPrice, previousMonth }
  }

  if (vehicles.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">No hay vehículos registrados. Comienza agregando uno.</p>
      </Card>
    )
  }

  return (
    <div className="grid gap-4">
      {vehicles.map((vehicle) => {
        const change = getPriceChange(vehicle)
        const currentPrice = vehicle.prices[currentMonth] || 0

        return (
          <Card key={vehicle.id} className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">{vehicle.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">{vehicle.description}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Precio Actual</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-sm">$</span>
                  <Input
                    type="number"
                    value={currentPrice}
                    onChange={(e) => onUpdatePrice(vehicle.id, Number.parseFloat(e.target.value))}
                    className="w-32"
                  />
                </div>
              </div>

              <div>
                {change ? (
                  <div>
                    <p className="text-sm text-muted-foreground">Cambio vs {change.previousMonth}</p>
                    <div
                      className={`mt-1 text-lg font-semibold ${change.diff >= 0 ? "text-red-600" : "text-green-600"}`}
                    >
                      {change.diff >= 0 ? "+" : ""} ${Math.abs(change.diff).toLocaleString("es-AR")} ({change.percent}%)
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Precio anterior: ${change.previous.toLocaleString("es-AR")}
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-sm text-muted-foreground">Sin comparativa</p>
                    <p className="text-xs text-muted-foreground mt-2">Este es el primer mes</p>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <Button variant="destructive" size="sm" onClick={() => onDelete(vehicle.id)}>
                Eliminar
              </Button>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
