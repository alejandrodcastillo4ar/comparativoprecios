"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { VehicleList } from "./vehicle-list"
import { AddVehicleForm } from "./add-vehicle-form"
import { MonthlyComparison } from "./monthly-comparison"
import { Statistics } from "./statistics"
import { CSVImporter } from "./csv-importer"
import {
  getAllVehiclesWithPrices,
  updateVehiclePrice,
  deleteVehicle as deleteVehicleService,
} from "@/lib/vehicle-service"
import type { Vehicle } from "@/lib/types"

interface VehicleWithPrices extends Vehicle {
  prices: Record<string, number>
}

export function Dashboard() {
  const [vehicles, setVehicles] = useState<VehicleWithPrices[]>([])
  const [currentMonth, setCurrentMonth] = useState<string>(new Date().toISOString().slice(0, 7))
  const [showAddForm, setShowAddForm] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Load vehicles from Supabase
  useEffect(() => {
    loadVehicles()
  }, [])

  const loadVehicles = async () => {
    try {
      setIsLoading(true)
      const data = await getAllVehiclesWithPrices()
      setVehicles(data)
    } catch (error) {
      console.error("Error loading vehicles:", error)
      alert("Error al cargar los vehículos")
    } finally {
      setIsLoading(false)
    }
  }

  const updateVehiclePriceInDb = async (vehicleId: string, newPrice: number) => {
    try {
      await updateVehiclePrice(vehicleId, currentMonth, newPrice)
      // Update local state
      setVehicles(
        vehicles.map((v) =>
          v.id === vehicleId
            ? {
                ...v,
                prices: {
                  ...v.prices,
                  [currentMonth]: newPrice,
                },
              }
            : v,
        ),
      )
    } catch (error) {
      console.error("Error updating price:", error)
      alert("Error al actualizar el precio")
    }
  }

  const deleteVehicleFromDb = async (vehicleId: string) => {
    try {
      await deleteVehicleService(vehicleId)
      setVehicles(vehicles.filter((v) => v.id !== vehicleId))
    } catch (error) {
      console.error("Error deleting vehicle:", error)
      alert("Error al eliminar el vehículo")
    }
  }

  const moveToNextMonth = () => {
    const currentDate = new Date(currentMonth + "-01")
    const nextMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)
    const newMonth = nextMonth.toISOString().slice(0, 7)
    setCurrentMonth(newMonth)
  }

  const moveToPreviousMonth = () => {
    const currentDate = new Date(currentMonth + "-01")
    const prevMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1)
    const newMonth = prevMonth.toISOString().slice(0, 7)
    setCurrentMonth(newMonth)
  }

  const handleAddVehicleSuccess = () => {
    setShowAddForm(false)
    loadVehicles()
  }

  const handleImportSuccess = () => {
    loadVehicles()
  }

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8 text-center">
        <p className="text-muted-foreground">Cargando vehículos...</p>
      </div>
    )
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-semibold text-foreground">
            Mes actual: {new Date(currentMonth + "-01").toLocaleDateString("es-ES", { month: "long", year: "numeric" })}
          </h2>
          <p className="text-muted-foreground text-sm mt-1">Total de vehículos: {vehicles.length}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={moveToPreviousMonth}>
            Mes anterior
          </Button>
          <Button variant="outline" onClick={moveToNextMonth}>
            Mes siguiente
          </Button>
        </div>
      </div>

      <Tabs defaultValue="vehicles" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="vehicles">Vehículos</TabsTrigger>
          <TabsTrigger value="comparison">Comparativa</TabsTrigger>
          <TabsTrigger value="statistics">Estadísticas</TabsTrigger>
          <TabsTrigger value="import">Importar Excel/CSV</TabsTrigger>
        </TabsList>

        <TabsContent value="vehicles" className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={() => setShowAddForm(!showAddForm)}>
              {showAddForm ? "Cancelar" : "+ Agregar Vehículo"}
            </Button>
          </div>

          {showAddForm && (
            <div className="bg-card border border-border rounded-lg p-6 mb-6">
              <AddVehicleForm currentMonth={currentMonth} onAdd={handleAddVehicleSuccess} />
            </div>
          )}

          <VehicleList
            vehicles={vehicles}
            currentMonth={currentMonth}
            onUpdatePrice={updateVehiclePriceInDb}
            onDelete={deleteVehicleFromDb}
          />
        </TabsContent>

        <TabsContent value="comparison">
          <MonthlyComparison vehicles={vehicles} currentMonth={currentMonth} />
        </TabsContent>

        <TabsContent value="statistics">
          <Statistics vehicles={vehicles} currentMonth={currentMonth} />
        </TabsContent>

        <TabsContent value="import">
          <CSVImporter currentMonth={currentMonth} onImport={handleImportSuccess} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
