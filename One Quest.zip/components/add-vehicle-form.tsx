"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { addVehicle, updateVehiclePrice } from "@/lib/vehicle-service"

interface AddVehicleFormProps {
  onAdd: () => void
  currentMonth: string
}

export function AddVehicleForm({ onAdd, currentMonth }: AddVehicleFormProps) {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [currentPrice, setCurrentPrice] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !currentPrice) {
      alert("Por favor completa los campos obligatorios")
      return
    }

    try {
      setIsLoading(true)
      const vehicle = await addVehicle(name, description)
      await updateVehiclePrice(vehicle.id, currentMonth, Number.parseFloat(currentPrice))

      setName("")
      setDescription("")
      setCurrentPrice("")
      onAdd()
    } catch (error) {
      console.error("Error adding vehicle:", error)
      alert("Error al agregar el vehículo")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Nombre del vehículo *</Label>
        <Input
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Ej: Toyota Corolla 2020"
          disabled={isLoading}
        />
      </div>

      <div>
        <Label htmlFor="description">Descripción</Label>
        <Input
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Ej: Azul, 80.000 km"
          disabled={isLoading}
        />
      </div>

      <div>
        <Label htmlFor="currentPrice">Precio actual (ARS) *</Label>
        <Input
          id="currentPrice"
          type="number"
          value={currentPrice}
          onChange={(e) => setCurrentPrice(e.target.value)}
          placeholder="0"
          disabled={isLoading}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isLoading}>
        {isLoading ? "Guardando..." : "Agregar Vehículo"}
      </Button>
    </form>
  )
}
