"use client"

import { Card } from "@/components/ui/card"
import type { Vehicle } from "@/lib/types"

interface MonthlyComparisonProps {
  vehicles: Vehicle[]
  currentMonth: string
}

export function MonthlyComparison({ vehicles, currentMonth }: MonthlyComparisonProps) {
  const getComparison = (vehicle: Vehicle) => {
    const currentMonthPrice = vehicle.prices?.[currentMonth]

    // Get previous month (lexicographically)
    const months = vehicle.prices ? Object.keys(vehicle.prices).sort() : []
    const currentIndex = months.indexOf(currentMonth)

    if (currentIndex <= 0 || !currentMonthPrice) return null

    const previousMonth = months[currentIndex - 1]
    const previousPrice = vehicle.prices![previousMonth]

    const diff = currentMonthPrice - previousPrice
    const percent = ((diff / previousPrice) * 100).toFixed(2)

    return {
      current: currentMonthPrice,
      previous: previousPrice,
      diff,
      percent,
      previousMonth,
    }
  }

  const comparisons = vehicles
    .map((v) => ({
      vehicle: v,
      comparison: getComparison(v),
    }))
    .filter((item) => item.comparison !== null)
    .sort((a, b) => {
      const aPercent = Number.parseFloat(a.comparison!.percent)
      const bPercent = Number.parseFloat(b.comparison!.percent)
      return bPercent - aPercent
    })

  if (comparisons.length === 0) {
    return (
      <Card className="p-8 text-center">
        <p className="text-muted-foreground">
          No hay comparativas disponibles. Necesitas tener precios en al menos 2 meses diferentes.
        </p>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {comparisons.map(({ vehicle, comparison }) => (
          <Card key={vehicle.id} className="p-6">
            <h3 className="font-semibold text-foreground mb-1">{vehicle.name}</h3>
            <p className="text-xs text-muted-foreground mb-4">{vehicle.description}</p>

            <div className="space-y-3">
              <div>
                <p className="text-xs text-muted-foreground">{comparison!.previousMonth}</p>
                <p className="text-base font-semibold text-foreground">
                  ${comparison!.previous.toLocaleString("es-AR")}
                </p>
              </div>

              <div>
                <p className="text-xs text-muted-foreground">{currentMonth}</p>
                <p className="text-base font-semibold text-foreground">
                  ${comparison!.current.toLocaleString("es-AR")}
                </p>
              </div>

              <div className="border-t border-border pt-3">
                <p className="text-xs text-muted-foreground mb-2">Variación</p>
                <div className={`text-2xl font-bold ${comparison!.diff >= 0 ? "text-red-600" : "text-green-600"}`}>
                  {comparison!.diff >= 0 ? "+" : ""} $
                  {Math.abs(Number.parseFloat(comparison!.diff.toString())).toLocaleString("es-AR")}
                </div>
                <p
                  className={`text-sm font-semibold mt-1 ${comparison!.diff >= 0 ? "text-red-600" : "text-green-600"}`}
                >
                  {comparison!.diff >= 0 ? "↑" : "↓"} {Math.abs(Number.parseFloat(comparison!.percent))}%
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
