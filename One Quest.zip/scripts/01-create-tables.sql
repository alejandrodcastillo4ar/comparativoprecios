-- Create vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create vehicle_prices table (stores prices by month)
CREATE TABLE IF NOT EXISTS vehicle_prices (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  month TEXT NOT NULL,
  price NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(vehicle_id, month)
);

-- Create comparisons table (stores saved comparatives)
CREATE TABLE IF NOT EXISTS comparisons (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  month TEXT NOT NULL,
  vehicle_id UUID NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  previous_month TEXT NOT NULL,
  previous_price NUMERIC NOT NULL,
  current_price NUMERIC NOT NULL,
  difference NUMERIC NOT NULL,
  percentage NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS (Row Level Security) - IMPORTANT FOR SECURITY
ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;
ALTER TABLE vehicle_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE comparisons ENABLE ROW LEVEL SECURITY;

-- Create policies for public access
CREATE POLICY "Allow public select vehicles" ON vehicles
  FOR SELECT USING (TRUE);

CREATE POLICY "Allow public insert vehicles" ON vehicles
  FOR INSERT WITH CHECK (TRUE);

CREATE POLICY "Allow public update vehicles" ON vehicles
  FOR UPDATE USING (TRUE);

CREATE POLICY "Allow public delete vehicles" ON vehicles
  FOR DELETE USING (TRUE);

CREATE POLICY "Allow public select prices" ON vehicle_prices
  FOR SELECT USING (TRUE);

CREATE POLICY "Allow public insert prices" ON vehicle_prices
  FOR INSERT WITH CHECK (TRUE);

CREATE POLICY "Allow public update prices" ON vehicle_prices
  FOR UPDATE USING (TRUE);

CREATE POLICY "Allow public delete prices" ON vehicle_prices
  FOR DELETE USING (TRUE);

CREATE POLICY "Allow public select comparisons" ON comparisons
  FOR SELECT USING (TRUE);

CREATE POLICY "Allow public insert comparisons" ON comparisons
  FOR INSERT WITH CHECK (TRUE);

CREATE POLICY "Allow public delete comparisons" ON comparisons
  FOR DELETE USING (TRUE);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_vehicle_prices_vehicle_id ON vehicle_prices(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_vehicle_prices_month ON vehicle_prices(month);
CREATE INDEX IF NOT EXISTS idx_comparisons_vehicle_id ON comparisons(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_comparisons_month ON comparisons(month);
