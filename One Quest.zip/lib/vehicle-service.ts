import { supabase } from "./supabase"
import type { Vehicle } from "./types"

export async function getVehicles(): Promise<Vehicle[]> {
  const { data, error } = await supabase.from("vehicles").select("*").order("created_at", { ascending: false })

  if (error) throw error
  return data || []
}

export async function getVehicleWithPrices(
  vehicleId: string,
): Promise<(Vehicle & { prices: Record<string, number> }) | null> {
  const { data: vehicle, error: vehicleError } = await supabase
    .from("vehicles")
    .select("*")
    .eq("id", vehicleId)
    .single()

  if (vehicleError) throw vehicleError
  if (!vehicle) return null

  const { data: prices, error: pricesError } = await supabase
    .from("vehicle_prices")
    .select("*")
    .eq("vehicle_id", vehicleId)

  if (pricesError) throw pricesError

  const pricesMap =
    prices?.reduce(
      (acc, p) => {
        acc[p.month] = p.price
        return acc
      },
      {} as Record<string, number>,
    ) || {}

  return { ...vehicle, prices: pricesMap }
}

export async function getAllVehiclesWithPrices(): Promise<(Vehicle & { prices: Record<string, number> })[]> {
  const { data: vehicles, error: vehiclesError } = await supabase
    .from("vehicles")
    .select("*")
    .order("created_at", { ascending: false })

  if (vehiclesError) throw vehiclesError
  if (!vehicles || vehicles.length === 0) return []

  const vehicleIds = vehicles.map((v) => v.id)
  const { data: prices, error: pricesError } = await supabase
    .from("vehicle_prices")
    .select("*")
    .in("vehicle_id", vehicleIds)

  if (pricesError) throw pricesError

  const pricesByVehicle = (prices || []).reduce(
    (acc, p) => {
      if (!acc[p.vehicle_id]) acc[p.vehicle_id] = {}
      acc[p.vehicle_id][p.month] = p.price
      return acc
    },
    {} as Record<string, Record<string, number>>,
  )

  return vehicles.map((v) => ({
    ...v,
    prices: pricesByVehicle[v.id] || {},
  }))
}

export async function addVehicle(name: string, description: string): Promise<Vehicle> {
  const { data, error } = await supabase.from("vehicles").insert([{ name, description }]).select().single()

  if (error) throw error
  return data
}

export async function updateVehiclePrice(vehicleId: string, month: string, price: number): Promise<void> {
  const { error } = await supabase.from("vehicle_prices").upsert(
    {
      vehicle_id: vehicleId,
      month,
      price,
    },
    {
      onConflict: "vehicle_id,month",
    },
  )

  if (error) throw error
}

export async function deleteVehicle(vehicleId: string): Promise<void> {
  const { error } = await supabase.from("vehicles").delete().eq("id", vehicleId)

  if (error) throw error
}
