export interface Vehicle {
  id: string
  name: string
  description: string
  created_at?: string
  updated_at?: string
}

export interface VehiclePrice {
  id: string
  vehicle_id: string
  month: string
  price: number
  created_at?: string
  updated_at?: string
}

export interface PriceHistory {
  vehicleId: string
  month: string
  price: number
  previousPrice?: number
}
