"use client"

import { useState, useEffect } from "react"
import { Dashboard } from "@/components/dashboard"
import { Header } from "@/components/header"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <Dashboard />
    </main>
  )
}
